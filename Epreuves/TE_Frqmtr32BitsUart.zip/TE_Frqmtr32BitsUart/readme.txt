Emplacement de ce fichier:
"C:\microchip\harmony\v2_06\apps\MINF\Epreuves\TE_Frqmtr32BitsUart\readme.txt"

Versions des logiciels:
MPLABX 5.50
xc32 2.50
Harmony 2.06

Auteur:
5.05.2025
SCA@etml-es
