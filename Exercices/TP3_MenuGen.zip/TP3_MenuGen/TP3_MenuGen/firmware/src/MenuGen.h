// Tp3  manipulation MenuGen avec PEC12
// C. HUBER  03.02.2016
// Fichier MenuGen.h
// Gestion du menu  du générateur
// Traitement cyclique à 1 ms du Pec12
// Date modif : 18.03.2025

#ifndef MenuGen_h
#define MenuGen_h


#include <stdbool.h>
#include <stdint.h>
#include "GesPec12.h"
#include "DefMenuGen.h"
#include "app.h"
#include "Mc32NVMUtil.h"


//========================================================
// Définitions des états du menu
//========================================================
// Les états SELECT... indiquent la mise en surbrillance d’un paramètre.
// Les états REGLAGE... indiquent que l’on modifie effectivement ce paramètre.
#define SELECTFORME       1
#define REGLAGEFORME      2
#define SELECTFREQUENCE   3
#define REGLAGEFREQUENCE  4
#define SELECTAMPLITUDE   5
#define REGLAGEAMPLITUDE  6
#define SELECTOFFSET      7
#define REGLAGEOFFSET     8
#define SAVEMODE          9  // État spécial pour gérer la sauvegarde

//========================================================
// Paramétrage de la fréquence
//========================================================
#define PAS_FREQUENCE  20    // Incrément ou décrément en Hz
#define FREQUENCE_MAX  2000  // Fréquence maximale en Hz
#define FREQUENCE_MIN  20    // Fréquence minimale en Hz

//========================================================
// Paramétrage de l’amplitude
//========================================================
#define PAS_AMPLITUDE  100   // Incrément ou décrément en mV
#define AMPLITUDE_MAX  10000 // Amplitude maximale en mV
#define AMPLITUDE_MIN  0     // Amplitude minimale en mV

//========================================================
// Paramétrage de l’offset
//========================================================
#define PAS_OFFSET     100   // Incrément ou décrément en mV
#define OFFSET_MAX     5000  // Offset maximal en mV
#define OFFSET_MIN    -5000  // Offset minimal en mV

//========================================================
// Prototypes de fonctions
//========================================================


void MENU_Initialize(S_ParamGen *pParam);


void MENU_Execute(S_ParamGen *pParam);


#endif



