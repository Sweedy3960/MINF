// Tp3  manipulation MenuGen avec PEC12
// C. HUBER  10/02/2015 pour SLO2 2014-2015
// Fichier MenuGen.c
// Gestion du menu  du générateur
// Traitement cyclique à 10 ms
// Date modif : 18.03.2025


#include <stdint.h>                   
#include <stdbool.h>
#include <MenuGen.h>
#include "GesPec12.h"
#include "Generateur.h"
#include "Mc32DriverLcd.h"
#include "bsp.h"
#include "app.h"
#include "Mc32NVMUtil.h"
#include "Mc32SpiUtil.h"


// Tableau de 4 chaînes de caractères (jusqu’à 21 caractères),
// représentant chacun un nom de forme d’onde.
const char forme [4][21] = {"Sinus", "Triangle", "DentDeScie", "Carre"};

/****************************************************************************
* MENU_Initialize
* 
* Fonction d'initialisation du menu. Permet d'afficher les paramètres sur le LCD
* Paramètres:
*   pParam (S_ParamGen*) : Pointeur vers les paramètres à appliquer
* 
* Comportement:
*   Affichage du menu d'initialisation
* 
****************************************************************************/

void MENU_Initialize(S_ParamGen *pParam) {
    lcd_gotoxy(1, 1);
    printf_lcd(" Forme = %10s", pParam->Forme);
    lcd_gotoxy(1, 2);
    printf_lcd(" Freq [Hz] = %4d", pParam->Frequence);
    lcd_gotoxy(1, 3);
    printf_lcd(" Ampl [mV] = %5d", pParam->Amplitude);
    lcd_gotoxy(1, 4);
    printf_lcd(" Offset [mV] = %5d", pParam->Offset);
}


/****************************************************************************
* MENU_Execute
* 
* Fonction d'execution du menu. Permet à l'utilisateur de choisir et
* modifier les paramètres du signal 
* Paramètres:
*   pParam (S_ParamGen*) : Pointeur vers les paramètres à appliquer
* 
* Comportement:
*   Affichage du menu
* 
****************************************************************************/

void MENU_Execute(S_ParamGen *pParam) {
    static uint8_t etat = SELECTFORME;
    static uint8_t ancienEtat = 1;
    static uint8_t attenteSave = 0;
    static char car = '*';
    static uint8_t editionMode = 0;
    static uint8_t premiereExecution = 0;
    static S_ParamGen valeurTemporaire;

    GENSIG_UpdatePeriode(pParam);
    GENSIG_UpdateSignal(pParam);
    //Première execution du programme ?
    if (premiereExecution == 0) {
        MENU_Initialize(pParam);          // appel de la fonction d'init du menu
        valeurTemporaire = *pParam;       // Enregistrement de la valeur initiale de *pParam dans valeurTemporaire pour s'y référer plus tard si nécessaire.
        premiereExecution = 1;            // Marque la fin de la première initialisation
    }
    // Enlève le curseur de la ligne sur la colonne 1 si il y a une diff entre les 2 états 
    //de plus de 2 exemple : ancien SELECTOFFSET(7) - nouveau SELECTFREQUENCE(4) = 3
    if ((abs(ancienEtat - etat)) >= 2) {
        lcd_gotoxy(1, 1);
        printf_lcd(" ");
        lcd_gotoxy(1, 2);
        printf_lcd(" ");
        lcd_gotoxy(1, 3);
        printf_lcd(" ");
        lcd_gotoxy(1, 4);
        printf_lcd(" ");
    }

    // Sauvegarde de l'état du menu dans une variable pour faire une vérif si il y a un changement
    ancienEtat = etat;
    //Selection pas d'édition de paramètres
    if (editionMode == 0) {
        // mode de sauvegarde ?
        if (etat != SAVEMODE) {
            // Affichage des paramètres actuels :
            // - Forme du signal
            lcd_gotoxy(2, 1);
            printf_lcd("Forme = %10s", forme[pParam->Forme]);
            // - Fréquence en Hz
            lcd_gotoxy(2, 2);
            printf_lcd("Freq [Hz] = %4d", pParam->Frequence);
            // - Amplitude en mV
            lcd_gotoxy(2, 3);
            printf_lcd("Ampl [mV] = %5d", pParam->Amplitude);
            // - Offset en mV
            lcd_gotoxy(2, 4);
            printf_lcd("Offset [mV] = %5d", pParam->Offset);
            // Vérification de l'appui sur le bouton S9 (OK)
            if (S9IsOK()) {
                // L'appui indique une activité, donc on réinitialise le compteur d’inactivité
                Pec12ClearInactivity();
                // Passer à l'état de sauvegarde
                etat = SAVEMODE;
                // Clear de S9
                S9ClearESC();
                S9ClearOK();
            }

            // Vérification de l'appui sur le bouton OK de l’encodeur (Pec12)
            if (Pec12IsOK()) {
                
                Pec12ClearOK();     // On efface l’état "OK" pour éviter une redétection immédiate
                editionMode = 1;    // Passage en mode édition
                etat += 1;             // On change d’état (état suivant) en réglage
                car = '?';            // changement du caractère pour indiquer le réglage du paramètre
            }

             // Gestion de la rotation vers la gauche de l’encodeur (Pec12IsMinus)
            if (Pec12IsMinus()) {
                Pec12ClearMinus();    // CLear pour redétecté une action
                // Si on est déjà au premier paramètre (SELECTFORME), on reboucle vers le dernier (SELECTOFFSET)
                // Sinon, on recule de deux étapes dans la liste de paramètres
                if (etat <= SELECTFORME) {
                    etat = SELECTOFFSET;
                }
                else {
                    etat -= 2;
                }
            }

            // Gestion de la rotation vers la droite de l’encodeur (Pec12IsPlus)
            if (Pec12IsPlus()) {
                Pec12ClearPlus();    // CLear pour redétecté une action
                // Si on est déjà au dernier paramètre (SELECTOFFSET), on reboucle vers le premier (SELECTFORME)
                // Sinon, on avance de deux étapes dans la liste de paramètres
                if (etat >= SELECTOFFSET) {
                    etat = SELECTFORME;
                }
                else {
                    etat += 2;
                }
            }
        }
    }
    // Si l'on est en mode édition (editionMode == 1) :
    if (editionMode == 1) {
        // Tant que l'état n'est pas SAVEMODE (mode de sauvegarde),
        // on affiche les valeurs "temporairement" modifiées (valeurTemporaire),
        // au lieu des valeurs réelles du paramètre pointé par pParam.
        if (etat != SAVEMODE) {
            // Affichage des paramètres en cours d'édition :
            // - Forme du signal
            lcd_gotoxy(2, 1);
            printf_lcd("Forme = %10s", forme[valeurTemporaire.Forme]);
            // - Fréquence en Hz
            lcd_gotoxy(2, 2);
            printf_lcd("Freq [Hz] = %4d", valeurTemporaire.Frequence);
            // - Amplitude en mV
            lcd_gotoxy(2, 3);
            printf_lcd("Ampl [mV] = %5d", valeurTemporaire.Amplitude);
            // - Offset en mV
            lcd_gotoxy(2, 4);
            printf_lcd("Offset [mV] = %5d", valeurTemporaire.Offset);
            // Si l'utilisateur valide les modifications en appuyant sur OK :
            if (Pec12IsOK()) {
                Pec12ClearOK();
                // On remplace la valeur pointée par pParam par la valeur temporaire validée
                *pParam = valeurTemporaire;
                // On revient à l'état précédent (état -= 1)
                etat -= 1;
                // On marque la ligne comme sélectionnée ou validée avec un caractère '*'
                car = '*';
                // On quitte le mode édition
                editionMode = 0;
            }
            // Si l'utilisateur annule les modifications en appuyant sur ESC :
            if (Pec12IsESC()) {
                Pec12ClearESC();
                // On restaure la structure temporaire à partir des valeurs réelles de pParam,
                // autrement dit on annule les changements effectués
                valeurTemporaire = *pParam;
                // On revient à l'état précédent
                etat -= 1;
                // On marque la ligne comme sélectionnée ou validée avec un caractère '*'
                car = '*';
                // On quitte le mode édition
                editionMode = 0;
            }
            // Gestion de l'augmentation (Pec12IsPlus) de la valeur en cours d'édition
            if (Pec12IsPlus()) {
                Pec12ClearPlus();
                // On modifie la valeur temporaire en fonction de l'état actuel
                // (REGLAGEFORME, REGLAGEFREQUENCE, REGLAGEAMPLITUDE ou REGLAGEOFFSET)
                switch (etat) {
                    // Si la forme est strictement inférieure à SignalCarre,
                    // on incrémente (forme suivante)
                    case REGLAGEFORME:
                        if (valeurTemporaire.Forme < SignalCarre) {
                            valeurTemporaire.Forme++;
                        }
                        else {
                            // Sinon, on reboucle vers la forme de départ (SignalSinus)
                            valeurTemporaire.Forme = SignalSinus;
                        }
                        break;
                    case REGLAGEFREQUENCE:
                        // S'il reste de la marge (moins de 2000 Hz), on l'augmente par le pas souhaité
                        if (valeurTemporaire.Frequence < 2000) {
                            valeurTemporaire.Frequence += PAS_FREQUENCE;
                        }
                        // Si on est déjà à la fréquence maximale, on reboucle vers la fréquence minimale
                        else if (valeurTemporaire.Frequence == FREQUENCE_MAX) {
                            valeurTemporaire.Frequence = FREQUENCE_MIN;
                        }

                        break;
                    case REGLAGEAMPLITUDE:
                        // Si on est en dessous de l'amplitude max, on incrémente de PAS_AMPLITUDE
                        if (valeurTemporaire.Amplitude < AMPLITUDE_MAX) {
                            valeurTemporaire.Amplitude += PAS_AMPLITUDE;
                        }
                        // Si on est déjà à l'amplitude max, on reboucle vers l'amplitude min
                        else if (valeurTemporaire.Amplitude == AMPLITUDE_MAX) {
                            valeurTemporaire.Amplitude = AMPLITUDE_MIN;
                        }

                        break;
                    case REGLAGEOFFSET:
                        // Si on est en dessous de l'offset max, on incrémente de PAS_OFFSET
                        if (valeurTemporaire.Offset < OFFSET_MAX) {
                            valeurTemporaire.Offset += PAS_OFFSET;
                        }
                        // Si on est déjà à l'offset max, on y reste (butée)
                        else if (valeurTemporaire.Offset == OFFSET_MAX) {
                            valeurTemporaire.Offset = OFFSET_MAX;
                        }
                        break;
                }
            }
            // Gestion de la diminution (Pec12IsMinus) de la valeur en cours d'édition
            if (Pec12IsMinus()) {
                Pec12ClearMinus();
                switch (etat) {
                    case REGLAGEFORME:
                        // Si la forme est supérieure à la forme la plus basse (SignalSinus),
                        // on décrémente (forme précédente)
                        if (valeurTemporaire.Forme > SignalSinus) {
                            valeurTemporaire.Forme--;
                        }
                        // Sinon, on reboucle vers la forme la plus haute (SignalCarre)    
                        else {
                            valeurTemporaire.Forme = SignalCarre;
                        }
                        break;
                    case REGLAGEFREQUENCE:
                        // Si la fréquence est supérieure à la freq minimale, on la diminue par le pas souhaité
                        if (valeurTemporaire.Frequence > FREQUENCE_MIN) {
                            valeurTemporaire.Frequence -= PAS_FREQUENCE;
                        }
                        // Si on est déjà à la fréquence min, on reboucle vers la fréquence max
                        else if (valeurTemporaire.Frequence == FREQUENCE_MIN) {
                            valeurTemporaire.Frequence = FREQUENCE_MAX;
                        }

                        break;
                    case REGLAGEAMPLITUDE:
                        // Si l'amplitude est supérieure à AMPLITUDE_MIN, on la diminue par le pas souhaité
                        if (valeurTemporaire.Amplitude > AMPLITUDE_MIN) {
                            valeurTemporaire.Amplitude -= PAS_AMPLITUDE;
                        }
                        // Si on est déjà à l'amplitude min, on reboucle vers la max
                        else if (valeurTemporaire.Amplitude == AMPLITUDE_MIN) {
                            valeurTemporaire.Amplitude = AMPLITUDE_MAX;
                        }
                        break;
                    case REGLAGEOFFSET:
                        // Si l'offset est au-dessus du OFFSET_MIN, on le diminue
                        if (valeurTemporaire.Offset > OFFSET_MIN) {
                            valeurTemporaire.Offset -= PAS_OFFSET;
                        }
                         // S'il est déjà au min, on y reste (butée)  
                        else if (valeurTemporaire.Offset > OFFSET_MIN) {
                            valeurTemporaire.Offset =OFFSET_MIN;
                        }
                        break;
                }
            }
        }
    }

    // Ce switchcase permet d'afficher un caractère spécial (étoile '*' ou point d'interrogation '?')
    // selon l'état (etat) actuel. Le caractère est stocké dans la variable 'car'.
    // Dans chaque cas, on déplace le curseur au début de la ligne (colonne 1) puis on affiche 'car'.
    // Ensuite, si on est en SAVEMODE, on gère la sauvegarde ou l’annulation de celle-ci.

    switch (etat) {
            /////       FORME       /////
        case SELECTFORME:
            lcd_gotoxy(1, 1);
            printf_lcd("%c", car);
            break;
        case REGLAGEFORME:
            lcd_gotoxy(1, 1);
            printf_lcd("%c", car);
            break;
            /////       FREQUENCE       /////   
        case SELECTFREQUENCE:
            lcd_gotoxy(1, 2);
            printf_lcd("%c", car);
            break;
        case REGLAGEFREQUENCE:
            lcd_gotoxy(1, 2);
            printf_lcd("%c", car);

            break;
            /////       AMPLITUDE       /////     
        case SELECTAMPLITUDE:
            lcd_gotoxy(1, 3);
            printf_lcd("%c", car);
            break;
        case REGLAGEAMPLITUDE:
            lcd_gotoxy(1, 3);
            printf_lcd("%c", car);

            break;
            /////       OFFSET       /////     
        case SELECTOFFSET:
            lcd_gotoxy(1, 4);
            printf_lcd("%c", car);
            break;
        case REGLAGEOFFSET:
            lcd_gotoxy(1, 4);
            printf_lcd("%c", car);
            break;

        case SAVEMODE:
            // Ici, on gère la sauvegarde des paramètres.
            // - Un appui long sur S9 (ESC) confirme la sauvegarde.
            // - Toute autre action annule la sauvegarde.
            // - attenteSave est un compteur qui sert à retarder le retour au menu après 2 secondes (200 boucles).

            // Si le bouton S9 est pressé longuement (ESC)
            if (S9IsESC()) 
            {
                // On incrémente 'attenteSave', et on exécute immédiatement la sauvegarde (NVM_WriteBlock)
                attenteSave++; // Incrémentation du compteur
                NVM_WriteBlock((uint32_t*)pParam, sizeof (S_ParamGen));
                
                // On affiche un message de confirmation de la sauvegarde
                lcd_ClearLine(3);
                lcd_gotoxy(1, 2);
                printf_lcd("    Sauvegarde OK   ");

                // On réinitialise l’inactivité et les états du bouton S9
                Pec12ClearInactivity(); // Réinitialiser l'inactivité
                S9ClearESC(); // Réinitialise l'événement
                S9ClearOK(); // Au cas où un OK reste actif
            }
            // Autre action (ESC de l’encodeur, rotation, OK…)    
            else if ((Pec12IsESC()) || (Pec12IsMinus()) || (Pec12IsOK()) || (Pec12IsPlus())) {
                // On incrémente 'attenteSave', puis on affiche un message d’annulation de la sauvegarde
                attenteSave++; 
                lcd_ClearLine(3);
                lcd_gotoxy(1, 2);
                printf_lcd(" Sauvegarde ANNULEE ");

                // On réinitialise l’inactivité et les états de l’encodeur
                Pec12ClearInactivity();
                Pec12ClearOK();
                Pec12ClearESC();
                Pec12ClearMinus();
                Pec12ClearPlus();
            }

            /// On utilise le compteur 'attenteSave' pour gérer une temporisation de 2 secondes (200 boucles)
            if (attenteSave > 0) {
                attenteSave++;
                // Après 2 secondes, on efface l’écran, réinitialise le menu,
                // remet le compteur à zéro et revient à l’état initial (SELECTFORME)
                if (attenteSave > 200) {
                    lcd_ClearLine(2);
                    MENU_Initialize(pParam);
                    attenteSave = 0; // Remise à zéro du compteur
                    etat = SELECTFORME; // Retour à l'état initial
                }
            }
            // Si aucune action n'a encore été faite, on propose la sauvegarde
            // avec un message demandant un "appui long" pour confirmer
            else {
                lcd_ClearLine(1);
                lcd_ClearLine(4);
                lcd_gotoxy(1, 2);
                printf_lcd("    Sauvegarde ?    ");
                lcd_gotoxy(1, 3);
                printf_lcd("    (Appui long)    ");
            }
            break;

        default:
            break;
    }
}


