// Tp3  manipulation MenuGen avec PEC12
// C. HUBER  10/02/2015 pour SLO2 2014-2015
// Fichier MenuGen.c
// Gestion du menu  du g�n�rateur
// Traitement cyclique � 10 ms



#include <stdint.h>                   
#include <stdbool.h>
#include <MenuGen.h>
#include <GesPec12.h>

#include "Mc32DriverLcd.h"
#include "bsp.h"
#include "app.h"

// Initialisation du menu et des param�tres
void MENU_Initialize(S_ParamGen *pParam)
{
    lcd_gotoxy(2,1);
    printf_lcd("Forme = %10c", pParam->Forme/*valeurForme*/);
    lcd_gotoxy(2,2);
    printf_lcd("Freq [Hz] = %4d", pParam->Frequence/*valeurForme*/);
    lcd_gotoxy(2,3);
    printf_lcd("Ampl [mV] = %4d", pParam->Amplitude /*valeurForme*/);
    lcd_gotoxy(2,4);
    printf_lcd("Offset [mV] = %4d", pParam->Offset/*valeurForme*/);
}


//Execution du menu, appel cyclique depuis l'application
void MENU_Execute(S_ParamGen *pParam)
{
    static uint8_t curseur = 1;
    static uint8_t etat = 1;
    static char car = '*';
    
    MENU_Initialize(&LocalParamGen);
    lcd_gotoxy(1,curseur);
    printf_lcd("%c", car);

    /* Test de la lecture du Pec12 Rotation + Pression longue ou courte
    if(Pec12IsOK())
    {
        Pec12ClearOK();
        car = '#';
    }
    
    if(Pec12IsESC())
    {
        Pec12ClearESC();
        car = '*';
    }
    
    //rotation vers la gauche
    if(Pec12IsMinus())
    {
        Pec12ClearMinus();
        
        //d�calage du curseur vers le haut
        if(curseur <= 1)
        {
            curseur = 4;
        }
        else
        {
            curseur --;
        }
        
        lcd_gotoxy(1,curseur);
        printf_lcd("%c", car);
    }
    
    //rotation vers la droite
    if(Pec12IsPlus())
    {
        Pec12ClearPlus();
        
        //d�calage du curseur vers le bas        
        if(curseur >= 4)
        {
            curseur = 1;
        }
        else
        {
            curseur ++; 
        }
        
        lcd_gotoxy(1,curseur);
        printf_lcd("%c", car);
    }*/
    // rotation vers la gauche
    if(Pec12IsMinus())
    {
        Pec12ClearMinus();
        
        //d�calage du curseur vers le haut
        if(curseur <= 1)
        {
            curseur = 4;
        }
        else
        {
            curseur --;
        }
        MENU_Initialize(&LocalParamGen);
        lcd_gotoxy(1,curseur);
        printf_lcd("%c", car);
    }
    
    //rotation vers la droite
    if(Pec12IsPlus())
    {
        Pec12ClearPlus();
        
        //d�calage du curseur vers le bas        
        if(curseur >= 4)
        {
            curseur = 1;
        }
        else
        {
            curseur ++; 
        }
        MENU_Initialize(&LocalParamGen);
        lcd_gotoxy(1,curseur);
        printf_lcd("%c", car);
    }

    //pression courte sur Pec12
    if(Pec12IsOK())
    {
        Pec12ClearOK();
        car = '?';
    }
    // pression longue sur Pec12
    if(Pec12IsESC())
    {
        Pec12ClearESC();
        car = '*';
    }
    
    //rotation vers la gauche
    if(Pec12IsMinus())
    {
        Pec12ClearMinus();
        
        //d�calage du curseur vers le haut
        if(curseur <= 1)
        {
            curseur = 4;
        }
        else
        {
            curseur --;
        }

    }

    //rotation vers la droite
    if(Pec12IsPlus())
    {
        Pec12ClearPlus();
        
        //d�calage du curseur vers le bas        
        if(curseur >= 4)
        {
            curseur = 1;
        }
        else
        {
            curseur ++; 
        }

    }
    
    if (Pec12IsOK()) 
    {
        if (curseur == 1) 
        {
            etat = FORME;
        }
        else if (curseur == 2) 
        {
            etat = FREQUENCE;
        }
        else if (curseur == 3) 
        {
            etat = AMPLITUDE;
        }
        else
        {
            etat = OFFSET;
        }      
    }
    
    
    switch(etat)
    {
        case FORME :
            
            break;
            
        case FREQUENCE:
            if (Pec12IsMinus()) 
            {
                Pec12ClearMinus();
                
                if(Pec12IsPlus())
                {
                    if(pParam->Frequence >= 2000)
                    {
                        pParam->Frequence = 0;
                    }
                    else
                    {
                        pParam->Frequence +=20;
                    }
                }
                if(Pec12IsMinus())
                {
                    if(pParam->Frequence <= 20)
                    {
                        pParam->Frequence = 2000;
                    }
                    else
                    {
                        pParam->Frequence -=20;
                    }
                }
            }
            break;
            
        case AMPLITUDE :
            if (Pec12IsMinus()) 
            {
                Pec12ClearMinus();
                
                if(Pec12IsPlus())
                {
                    if(pParam->Amplitude >= 10000)
                    {
                        pParam->Amplitude = 0;
                    }
                    else
                    {
                        pParam->Amplitude +=100;
                    }
                }
                if(Pec12IsMinus())
                {
                    
                    if(pParam->Amplitude <= 0)
                    {
                        pParam->Amplitude = 10000;
                    }
                    else
                    {
                        pParam->Amplitude -=100;
                    }
                }
            }
            break;
            
        case OFFSET :
            if (Pec12IsMinus()) 
            {
                Pec12ClearMinus();
                
                if(Pec12IsPlus())
                {
                    pParam->Offset +=100;
                }
                if(Pec12IsMinus())
                {
                    pParam->Offset -=100;
                }
                
                if(pParam->Offset >= 5000)
                {
                    pParam->Offset = 5000;
                }
                if(pParam->Offset <= -5000)
                {
                    pParam->Offset = -5000;
                }   
            }
            break;    
              
    }    
}

    




