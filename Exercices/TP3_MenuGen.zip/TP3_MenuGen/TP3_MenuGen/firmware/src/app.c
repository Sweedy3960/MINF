/*******************************************************************************
  MPLAB Harmony Application Source File
  
  Company:
    Microchip Technology Inc.
  
  File Name:
    app.c

  Summary:
     Pour Tp3 Menu et generateur de signal .
 * 
 * 
 * //date modif 18.03.2025

  Description:
    This file contains the source code for the MPLAB Harmony application.  It 
    implements the logic of the application's state machine and it may call 
    API routines of other MPLAB Harmony modules in the system, such as drivers,
    system services, and middleware.  However, it does not call any of the
    system interfaces (such as the "Initialize" and "Tasks" functions) of any of
    the modules in the system or make any assumptions about when those functions
    are called.  That is the responsibility of the configuration-specific system
    files.
 *******************************************************************************/

// DOM-IGNORE-BEGIN
/*******************************************************************************
Copyright (c) 2013-2014 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 *******************************************************************************/
// DOM-IGNORE-END


// *****************************************************************************
// *****************************************************************************
// Section: Included Files 
// *****************************************************************************
// *****************************************************************************

#include "app.h"
#include "Mc32DriverLcd.h"
#include "Mc32gestSpiDac.h"
#include "MenuGen.h"
#include "GesPec12.h"
#include "Generateur.h"
#include "bsp.h"
#include "Mc32Debounce.h"


S_SwitchDescriptor DescrS9;

S_Pec12_Descriptor S9;


// *****************************************************************************
// *****************************************************************************
// Section: Global Data Definitions
// *****************************************************************************
// *****************************************************************************

// *****************************************************************************
/* Application Data

  Summary:
    Holds application data

  Description:
    This structure holds the application's data.

  Remarks:
    This structure should be initialized by the APP_Initialize function.
    
    Application strings and buffers are be defined outside this structure.
*/

APP_DATA appData;
S_ParamGen LocalParamGen;


// *****************************************************************************
// *****************************************************************************
// Section: Application Callback Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary callback funtions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Local Functions
// *****************************************************************************
// *****************************************************************************

/* TODO:  Add any necessary local functions.
*/


// *****************************************************************************
// *****************************************************************************
// Section: Application Initialization and State Machine Functions
// *****************************************************************************
// *****************************************************************************

/*******************************************************************************
  Function:
    void APP_Initialize ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Initialize ( void )
{
    /* Place the App state machine in its initial state. */
    appData.state = APP_STATE_INIT;
    
    /* TODO: Initialize your application's state machine and other
     * parameters.
     */
}


/******************************************************************************
  Function:
    void APP_Tasks ( void )

  Remarks:
    See prototype in app.h.
 */

void APP_Tasks ( void )
{
    /* Check the application's current state. */
    switch ( appData.state )
    {
        /* Application's initial state. */
        case APP_STATE_INIT:
        {
            // Initialisation et configuration de l’affichage LCD
            lcd_init();
            // Active le rétroéclairage du LCD
            lcd_bl_on();

            // Initialisation de la communication SPI pour le DAC LTC2604
            SPI_InitLTC2604();

            // Initialisation de l’encodeur rotatif PEC12
            Pec12Init();

            // Initialisation du bouton S9
            S9Init();

            // Initialisation du générateur de signaux avec les paramètres locaux
            GENSIG_Initialize(&LocalParamGen);

            // Affichage de l'écran de lancement sur le LCD
            printf_lcd("TP3 GenSig  24-25");
          
            // Affichage des noms sur deux lignes
            lcd_gotoxy(1,2);
            printf_lcd("Besson Nicolas");
            lcd_gotoxy(1,3);
            printf_lcd("Bucher Mathieu");

            // Active les timers 
            DRV_TMR0_Start();
            DRV_TMR1_Start();
          
            // Passage à l’état APP_STATE_WAIT
            appData.state = APP_STATE_WAIT;
            break;
        }
        case APP_STATE_WAIT :
          // nothing to do
        break;

       case APP_STATE_SERVICE_TASKS:
            BSP_LEDToggle(BSP_LED_2);
            // Execution du menu
            MENU_Execute(&LocalParamGen);
            appData.state = APP_STATE_WAIT;
         break;
        /* TODO: implement your application state machine.*/

        /* The default state should never be executed. */
        default:
        {
            /* TODO: Handle error in application's state machine. */
            break;
        }
    }
}


void APP_UpdateState ( APP_STATES NewState )
{
    appData.state = NewState;
}

/****************************************************************************
* S9
* 
* Fonctions d'execution du S9. Permet à l'utilisateur d'utiliser S9
* Paramètres:
*   bool valS9
* 
* Comportement:
*   S9 permet d'effectuer la sauvegarde sur l'EPROM
* 
****************************************************************************/

void ScanS9(bool valS9) {
    // Traitement de  l'antirebond sur S9 via le descripteur 'DescrS9'.
    DoDebounce(&DescrS9, valS9);

    // Incrémente la durée de pression tant que le bouton est appuyé (valS9 == 0).
    if (valS9 == 0) {
        S9.PressDuration++;
    }

    // Si on détecte que le bouton vient d'être relâché, on analyse la durée de pression.
    else if (DebounceIsReleased(&DescrS9)) 
    {
        // Si la durée de pression dépasse le seuil d'une "longue pression",
        // on déclenche l'action ESC (et on désactive l'action OK).
        if (S9.PressDuration >= PRESSION_LONGUE) 
        {
            S9.ESC = 1;  // Pression longue, action ESC
            S9.OK = 0;   // Désactive OK
        } 
        else {
            // Sinon, si c'est une pression courte, on déclenche l'action OK.
            S9.ESC = 0;   // Pression courte, action OK
            S9.OK = 1;    // Active OK
        }

        // Réinitialise la durée de pression 
        S9.PressDuration = 0;

    }
    // Une fois traitées, on remet à zéro les informations de rebond
    // pour éviter de dupliquer la détection
    DebounceClearPressed(&DescrS9);
    DebounceClearReleased(&DescrS9);
}


void S9Init(void) {
    // Initialise le descripteur de debounce pour S9.
    DebounceInit(&DescrS9);

    // Init de la structure S9
    S9.OK = 0; // action OK
    S9.ESC = 0; // action ESC
    S9.PressDuration = 0; // Compteur de durée d’appui sur le bouton
    
} // S9Init

//       S9IsOK         true indique action OK

bool S9IsOK(void) {
    return (S9.OK);
}

//       S9IsESC        true indique action ESC

bool S9IsESC(void) {
    return (S9.ESC);
}

//       S9ClearOK      annule indication action OK

void S9ClearOK(void) {
    S9.OK = 0;
}

//       S9ClearESC     annule indication action ESC

void S9ClearESC(void) {
    S9.ESC = 0;
}




/*******************************************************************************
 End of File
 */

