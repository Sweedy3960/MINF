/****************************************************************************
* Generateur.h
* 
* TP3 MenuGen 2016
* C. HUBER  03.02.2016
* 
* Prototypes des fonctions du g�n�rateur de signal.
* D�finit �galement FMCU, PRESCALER, V_MAX, et DAC_MAX
* pour configurer la conversion et la plage de fonctionnement du DAC.
* 
* Important : Aucun code existant n'a �t� modifi�, uniquement des commentaires.
****************************************************************************/
 
#ifndef Generateur_h
#define Generateur_h
 
#include <math.h>         // Pour les fonctions math�matiques si besoin
#include <stdint.h>       // Pour uint16_t, int16_t, etc.
#include <stdbool.h>      // Pour bool�en
#include "DefMenuGen.h"   // D�finitions du type S_ParamGen, Formes de signal
#include "Mc32NVMUtil.h"
 
// Configuration du microcontr�leur et du DAC
#define FMCU 80000000     // Fr�quence MCU : 80 MHz
#define PRESCALER 8       // Prescaler utilis� pour le Timer
#define V_MAX  10000      // +10V en mV (plage de tension max)
#define DAC_MAX 65535     // R�solution max du DAC (16 bits)
#define DAC_MIN 0         // R�solution min du DAC (16 bits)
#define CENTER 32767      // Centre du signal
 
// ---------------------------------------------------------------------------
// Prototypes des fonctions du g�n�rateur de signaux
// ---------------------------------------------------------------------------
 
/****************************************************************************
* GENSIG_Initialize
* 
* Param�tre:
*   pParam : Pointeur vers les param�tres de g�n�ration du signal
* 
* Fonction:
*   Initialise le g�n�rateur (ParamGen). Peut mettre des valeurs par d�faut
*   si pParam est NULL. Pr�pare le module pour la g�n�ration.
****************************************************************************/
void  GENSIG_Initialize(S_ParamGen *pParam);
 
/****************************************************************************
* GENSIG_UpdatePeriode
* 
* Param�tre:
*   pParam : Pointeur vers la structure contenant la fr�quence d�sir�e
* 
* Fonction:
*   Met � jour la p�riode du Timer 3 en fonction de la fr�quence du signal.
*   Evite la division par z�ro si pParam->Frequence vaut 0.
****************************************************************************/
void  GENSIG_UpdatePeriode(S_ParamGen *pParam);
 
/****************************************************************************
* GENSIG_UpdateSignal
* 
* Param�tre:
*   pParam : Pointeur vers les param�tres (forme, amplitude, offset)
* 
* Fonction:
*   Met � jour le tableau d'�chantillons (GenTable) pour correspondre � la
*   forme de signal s�lectionn�e. Convertit amplitude / offset en valeurs
*   DAC, applique l'�cr�tage, etc.
****************************************************************************/
void  GENSIG_UpdateSignal(S_ParamGen *pParam);
 
/****************************************************************************
* GENSIG_Execute
* 
* Fonction:
*   Appel�e dans l'interruption du Timer 3 pour envoyer les �chantillons
*   un par un au DAC (via SPI_WriteToDac).
****************************************************************************/
void  GENSIG_Execute(void);
 
#endif