/****************************************************************************
* Generateur.c
* 
* Canevas manipulation GenSig avec menu
* C. HUBER  09/02/2015
* 
* Fichier Gestion du générateur
* 
* Gère l'initialisation du générateur de signaux (GENSIG_Initialize),
* la mise à jour de la période d'échantillonnage (GENSIG_UpdatePeriode),
* la mise à jour du signal (GENSIG_UpdateSignal) selon la forme et les
* paramètres reçus, ainsi que l'exécution du générateur (GENSIG_Execute)
* envoyant les valeurs au DAC.
* 
* Important : Aucun code existant n'a été modifié, uniquement des commentaires
*             ont été ajoutés.
****************************************************************************/
 
#include "Generateur.h"          // Inclusion du header de ce module
#include "DefMenuGen.h"          // Définitions pour les signaux
#include "Mc32gestSpiDac.h"      // Gestion du DAC via SPI
#include "bsp.h"                 // Board Support Package
#include <math.h>                // Fonctions mathématiques (sin, M_PI)
#include "system_config.h"       // Configuration du système
#include "Mc32NVMUtil.h"
 
// Nombre d'échantillons par période
#define MAX_ECH 100
 
// Structure globale du générateur
S_ParamGen ParamGen;  // Stocke les paramètres du signal (forme, amplitude, offset, etc.)
 
// Table des échantillons générés
static float GenTable[MAX_ECH];  // Tableau contenant les valeurs à envoyer au DAC
 
/****************************************************************************
* GENSIG_Initialize
* 
* Fonction d'initialisation du générateur de signaux.
* Paramètres:
*   pParam (S_ParamGen*) : Pointeur vers les paramètres à appliquer
* 
* Comportement:
*   - Initialise des valeurs par défaut.
****************************************************************************/
void GENSIG_Initialize(S_ParamGen *pParam) {
    //Lecture dans l'EPROM
    NVM_ReadBlock((uint32_t*)&ParamGen, sizeof (S_ParamGen));

    // Initialisation par défaut des paramètres
    //Vérifie si ParamGen à la bonne valeur pour le paramètre "Magic"
    if (ParamGen.Magic == MAGIC) {
        *pParam = ParamGen;   //Met a jour la structure pointé pParam avec les valeurs de ParamGen
    }
    else{
        ParamGen = *pParam;   // Récupère les valeurs de pParam et les enregistre dans ParamGen
     // valeurs par défaut du menu
        pParam->Forme = SignalSinus;
        pParam->Frequence = 20;
        pParam->Amplitude = 0;
        pParam->Offset = 0;
        pParam->Magic = MAGIC;
    }
}
 
/****************************************************************************
* GENSIG_UpdatePeriode
* 
* Met à jour la période d'échantillonnage selon la fréquence indiquée dans
* la structure S_ParamGen.
* 
* Paramètres:
*   pParam (S_ParamGen*) : Pointeur vers les paramètres actuels
* 
* Comportement:
*   - Si Frequence = 0, on retourne directement pour éviter division par zéro.
*   - Calcule le nombre total d'échantillons par seconde (nbr_ech).
*   - Calcule la fréquence du timer après prédivision (frequ_presc).
*   - Détermine Periode = frequ_presc / nbr_ech.
*   - Mets à jour la période du Timer 3 par PLIB_TMR_Period16BitSet.
****************************************************************************/
void GENSIG_UpdatePeriode(S_ParamGen *pParam)
{
    if (pParam->Frequence == 0) return; // Évite la division par zéro
 
    uint32_t nbr_ech = MAX_ECH * pParam->Frequence;       // Nombre total d'échantillons par seconde
    uint32_t frequ_presc = FMCU / PRESCALER;             // Fréquence microcontrôleur / prescaler
    uint32_t Periode = frequ_presc / nbr_ech;            // Calcul de la période du timer
 
    PLIB_TMR_Period16BitSet(TMR_ID_3, Periode);          // Mise à jour de la période du Timer 3
}
 
/****************************************************************************
* GENSIG_UpdateSignal
* 
* Met à jour le signal (forme, amplitude, offset) et remplit le tableau
* GenTable avec les échantillons correspondant à la forme sélectionnée.
* 
* Paramètres:
*   pParam (S_ParamGen*) : Paramètres du signal (forme, amplitude, offset)
* 
* Comportement:
*   - Récupère amplitude et offset.
*   - Convertit ces valeurs en amplitudeDAC et offsetDAC en se basant sur
*     la configuration du DAC et la plage de tension (V_MAX, DAC_MAX).
*   - Calcule step, CENTER, etc., puis alimente GenTable selon la forme.
*   - Écrête les valeurs du tableau pour rester entre 0 et 65535 (plage DAC).
****************************************************************************/
void GENSIG_UpdateSignal(S_ParamGen *pParam)
{
    uint8_t i;                              // Index de boucle
    uint16_t amplitude = pParam->Amplitude; // Amplitude en mV 
    int16_t offset = pParam->Offset;       // Offset en mV 
    // Conversion amplitude et offset en valeur DAC
    uint16_t amplitudeDAC = ((amplitude*DAC_MAX)/V_MAX); 
    int16_t offsetDAC = (((offset*DAC_MAX)/V_MAX)/2);
 
    uint16_t step = amplitudeDAC / MAX_ECH; // Pas pour la dent de scie

    // Génération du signal selon la forme sélectionnée
    switch (pParam->Forme) 
    {
        case SignalSinus:
            for ( i = 0; i < MAX_ECH; i++) 
            {   
                GenTable[i] = ((amplitudeDAC / 2.0) * sin((2.0 * M_PI * i) / MAX_ECH)) + CENTER - offsetDAC;    
            }
            break;
 
        case SignalTriangle:
            for ( i = 0; i < MAX_ECH / 2; i++) 
            {
                GenTable[i] = ((2 * amplitudeDAC * i) / MAX_ECH) + CENTER - (amplitudeDAC / 2) - offsetDAC;
            }
            for ( i = MAX_ECH / 2; i < MAX_ECH; i++)
            {
                GenTable[i] = ((2 * amplitudeDAC * (MAX_ECH - i)) / MAX_ECH) + CENTER - (amplitudeDAC / 2) - offsetDAC;
            }
            break;
 
        case SignalDentDeScie:
            for ( i = 0; i < MAX_ECH; i++) 
            {
                GenTable[i] = (step * i) + CENTER - (amplitudeDAC / 2) - offsetDAC;
            }
            break;
 
        case SignalCarre:
            for ( i = 0; i < MAX_ECH; i++) 
            {
                if (i < MAX_ECH / 2)
                {
                    GenTable[i] = CENTER - (amplitudeDAC / 2) - offsetDAC; // Partie basse
                }
                else
                {
                    GenTable[i] = CENTER + (amplitudeDAC / 2) - offsetDAC; // Partie haute
                }
            }
            break;
 
        default:
            for ( i = 0; i < MAX_ECH; i++) 
            {
                GenTable[i] = (step * i) + CENTER - (amplitudeDAC / 2) - offsetDAC;
            }
            break;
    }        
 
    // Écrêtage des valeurs pour rester dans la plage DAC
    for ( i = 0; i < MAX_ECH; i++) 
    {
        if (GenTable[i] > DAC_MAX)
        {
            GenTable[i] = DAC_MAX; // Limite max
        }
        else if (GenTable[i] < DAC_MIN) 
        {
            GenTable[i] = DAC_MIN;     // Limite min
        }
    }
}
 
/****************************************************************************
* GENSIG_Execute
* 
* Fonction appelée périodiquement (par Timer3) pour envoyer les échantillons
* au DAC. Permet de faire défiler GenTable et produire le signal analogique.
* 
* Comportement:
*   - Utilise une variable statique EchNb pour l'index du tableau.
*   - Incrémente EchNb et envoie la valeur correspondante à SPI_WriteToDac().
*   - Revient à 0 quand EchNb atteint MAX_ECH.
****************************************************************************/
void GENSIG_Execute(void)
{
    static uint16_t EchNb = 0;
 
    if (EchNb >= MAX_ECH) 
    {
        EchNb = 0; // Réinitialisation
    }
 
    SPI_WriteToDac(0, GenTable[EchNb]);
    EchNb++;
}
